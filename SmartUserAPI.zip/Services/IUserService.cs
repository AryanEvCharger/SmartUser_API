using SmartUserAPI.Models;
using System.Collections.Generic;

namespace SmartUserAPI.Services
{
    public interface IUserService { IEnumerable<User> GetAll(); User Get(int id); void Add(User user); void Update(int id, User user); void Delete(int id); }
}

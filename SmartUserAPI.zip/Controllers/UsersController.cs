using Microsoft.AspNetCore.Mvc;
using SmartUserAPI.Models;
using SmartUserAPI.Services;

namespace SmartUserAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        public UsersController(IUserService userService) { _userService = userService; }

        [HttpGet] public IActionResult GetAll() => Ok(_userService.GetAll());

        [HttpGet("{id}")] public IActionResult Get(int id) { var user = _userService.Get(id); return user is null ? NotFound() : Ok(user); }

        [HttpPost] public IActionResult Create([FromBody] User user) { if(!ModelState.IsValid) return BadRequest(ModelState); _userService.Add(user); return CreatedAtAction(nameof(Get), new { id = user.Id }, user); }

        [HttpPut("{id}")] public IActionResult Update(int id, [FromBody] User updatedUser) { if (!ModelState.IsValid) return BadRequest(ModelState); var user = _userService.Get(id); if(user is null) return NotFound(); _userService.Update(id, updatedUser); return NoContent(); }

        [HttpDelete("{id}")] public IActionResult Delete(int id) { var user = _userService.Get(id); if(user is null) return NotFound(); _userService.Delete(id); return NoContent(); }
    }
}

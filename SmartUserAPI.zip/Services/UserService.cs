using SmartUserAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace SmartUserAPI.Services
{
    public class UserService : IUserService
    {
        private readonly List<User> _users = new(); private int _nextId = 1;
        public IEnumerable<User> GetAll() => _users;
        public User Get(int id) => _users.FirstOrDefault(u => u.Id == id);
        public void Add(User user) { user.Id = _nextId++; _users.Add(user); }
        public void Update(int id, User user) { var index = _users.FindIndex(u => u.Id == id); if (index != -1) { user.Id = id; _users[index] = user; } }
        public void Delete(int id) { var user = Get(id); if (user != null) _users.Remove(user); }
    }
}
